library(tidyverse)
library(TxDb.Hsapiens.UCSC.hg38.knownGene)
library(GenomicRanges)
library(Rsamtools)
library(DESeq2)
library(here)
library(Homo.sapiens)

txdb <- TxDb.Hsapiens.UCSC.hg38.knownGene




introns <- intronsByTranscript(txdb, use.names=TRUE)

ulst <- unlist(introns)
intronsNoDups <- ulst[!duplicated(ulst)]

setwd(here())

info <- read_tsv("longest_proteincoding_transcript_hs_details.txt") %>%
  mutate(short_id = str_sub(transcript_id, 1, 15))

txnames <- names(intronsNoDups)

names <- tr2g_TxDb(txdb, get_transcriptome = FALSE, write_tr2g = F)

exons <- data.frame(exonsBy(txdb, by="gene"))

intron_df <- data.frame(introns) %>%
  #dplyr::distinct(seqnames, start, end, strand, .keep_all=T) %>%
  dplyr::select(-group) %>%
  dplyr::mutate(short_id = str_sub(group_name, 1, 15)) %>%
  dplyr::filter(short_id %in% info$short_id) %>%
  group_by(short_id) %>%
  dplyr::arrange(start) %>%
  mutate(n = 1:n()) %>%
  mutate(intron_id = paste0(short_id, "_", n)) %>%
  ungroup() %>%
  dplyr::select(-n, -short_id)

intron_names <- intron_df %>% dplyr::select(seqname = group_name, intron_id)

write_csv(intron_names, "data/intron_ids.csv.gz")

intron_grange <- makeGRangesFromDataFrame(intron_df, keep.extra.columns = T)

exons <- exonsBy(txdb, by = "tx")

min_rl <- 27
max_rl <- 31

dir <- "//data.thecrick.org/lab-ulej/home/users/wilkino/ALL_RIBOSEQ/SRSF1_protrusions_iPSCS/sarah_hill_combined/snakemake_output/results/genome_dedup"

bams <- Sys.glob(paste0(dir, "/*.bam"))

for(bam in bams){
  sample_name = word(word(bam, -1, -1, sep="/"), 1, sep="\\.")
  bam_df <- data.frame(scanBam(bam)) %>%
    dplyr::select(seqnames = rname, start = pos, qwidth) %>%
    dplyr::filter(qwidth >= min_rl & qwidth <= max_rl) %>%
    mutate(end = start + qwidth)

  # convert to granges
  bam_grange <- makeGRangesFromDataFrame(bam_df)
  no_exon_overlaps <- subsetByOverlaps(bam_grange, exons, invert = T, type="any")

  intron_overlaps <- data.frame(findOverlapPairs(no_exon_overlaps, intron_grange)) %>%
    dplyr::select(intron_id=second.intron_id) %>%
    group_by(intron_id) %>%
    mutate(n_counts = n()) %>%
    unique() %>%
    mutate(sample = sample_name)

  if(bam == bams[1]){
    full_df = intron_overlaps
  } else {
    full_df <- bind_rows(full_df, intron_overlaps)
  }
}

write_csv(full_df, "intron_counts.csv.gz")
# full_df <- read_csv("intron_counts.csv.gz")
# 
# counts_df <- full_df %>%
#   pivot_wider(names_from="sample", values_from="n_counts") %>%
#   column_to_rownames("intron_id")
# 
# counts_df[is.na(counts_df)] <- 0
# 
# counts_matrix = as.matrix(counts_df)
# 
# col_data <- data.frame(condition = ifelse(str_detect(colnames(counts_df), "tdp"), "kd", "control"))
# 
# dds <- DESeqDataSetFromMatrix(countData = counts_matrix,
#                               colData = col_data,
#                               design= ~ condition)
# 
# dds <- DESeq(dds)
# resultsNames(dds) # lists the coefficients
# res <- results(dds, name="condition_kd_vs_control")
# 
# res_df <- data.frame(res) %>%
#   rownames_to_column("intron_id") %>%
#   left_join(intron_df, by = "intron_id")
# 
# res_df2 <- res_df %>%
#   mutate(color = ifelse(intron_id=="ENST00000518111_1", "red", "grey50")) %>%
#   filter(baseMean > 1)
# 
# ggplot(res_df2, aes(x = log2FoldChange, y = -log10(pvalue), color = color)) +
#   geom_point(size = 2, alpha = 0.5) +
#   scale_color_identity() +
#   theme_minimal() +
#   ggtitle("Differential intronic ribosome footprints (STMN2 = red)")
# 
# ggsave("intronic volcano.png")
# 
# 
# 
# yo <- res_df2 %>% 
#   mutate(short_id = str_sub(intron_id, 1, 15)) %>%
#   left_join(info, by ="short_id") %>%
#   filter(baseMean > 1)
# 
# write_csv(yo, "C:/Users/ogw/Google Drive/UCL PhD/Year 2/sarah hill/differential ribosome introns.csv")
