library(tidyverse)
library(here)
library(GenomicFeatures)
library(plyranges)
library(BSgenome.Hsapiens.UCSC.hg38)
g <- BSgenome.Hsapiens.UCSC.hg38
setwd(here())

# For each cryptic exon we need to:
# 1. Perform subset by overlaps to find all the "footprints" which align
#    to this cryptic exon
# 2. Identify the frame of the start of the cryptic exon
# 3. Record the frame, length and NAME of each read
#
# Then at the end we need to only count each footprint once, and of course 
# discard any footprints for which we weren't sure about the frame.


## Read in files

txdb <- makeTxDbFromGFF("C:/Users/ogw/Downloads/gencode.v29.annotation.gtf")

cds_ranges <- cdsBy(txdb, by = "tx", use.names=T)
cds_df <- data.frame(cds_ranges) %>%
  mutate(short_id = str_sub(group_name, 1, 15))

info <- read_tsv("longest_proteincoding_transcript_hs_details.txt") %>%
  mutate(short_id = str_sub(transcript_id, 1, 15))

cryptic_bed <- read_csv("curated_riboseq_periodicity/most_promising_cryptics_from_AL.csv")


longest_df <- cds_df %>%
  filter(short_id %in% info$short_id)

  
# identify the start and of each gene
genes <- longest_df %>%
  group_by(short_id) %>%
  mutate(gene_start = min(start),
         gene_end = max(end)) %>%
  dplyr::select(seqnames, start = gene_start, end = gene_end, strand, short_id) %>%
  unique() %>%
  ungroup() %>%
  as_granges()

cryptic_ranges <- cryptic_bed %>%
  as_granges()

i <- 1
for(i in 1:nrow(cryptic_bed)){
  
  if(i == 1){
    upstreams = c()
    full_seqs = c()
    names <- c()
  }
  
  this_range <- cryptic_ranges[i]
  this_strand <- cryptic_bed$strand[i]
  this_start <- cryptic_bed$start[i] + 1
  this_end <- cryptic_bed$end[i]
  this_chr <- cryptic_bed$seqnames[i]
  
  # Check that there's only one gene it could be inside
  parent_genes <- subsetByOverlaps(genes, this_range, ignore.strand=F)
  
  if(length(parent_genes) != 1){
    next
  }
  
  # Get CDS regions of relevant gene
  this_id <- parent_genes$short_id[1]
  
  relevant_cds <- cds_df %>%
    filter(short_id == this_id)
  
  # Find where this one slots in
  if(this_strand == "+"){
    upstream_cds <- relevant_cds %>% filter(end < this_start)
  } else {
    upstream_cds <- relevant_cds %>% filter(start > this_end)
  }
  
  # Verify that it's not after the stop codon
  if(nrow(upstream_cds) == nrow(relevant_cds)){
    next
  }
  # Verity that it's not before the start codon
  if(nrow(upstream_cds) == 0){
    next
  }
  
  # Identify where the stop codon is in the cryptic 
  upstream_cds_seq <- getSeq(g, upstream_cds %>% as_granges())
  cryptic_seq <- as.character(getSeq(g, this_range))
  combined_seq <- paste0(paste0(as.character(upstream_cds_seq), collapse=""),
                         cryptic_seq)
  
  # Translate the sequence and find the stop codon
  translated <- paste(translate(DNAStringSet(combined_seq), no.init.codon = T))
  
  if(str_detect(translated, "\\*")){
    stop_codon_position <- str_locate(translated, "\\*")[1]
    valid_nucleotides <- 3*stop_codon_position - 3 + 12  # add twelve in case things overlap
    to_align_to = str_sub(combined_seq, 1, valid_nucleotides)
  } else {
    to_align_to = combined_seq
  }
  
  upstreams = c(upstreams, paste0(upstream_cds_seq, collapse = ""))
  full_seqs = c(full_seqs, to_align_to)
  names <- c(names, cryptic_bed$gene_name[i])
}
 

final_df <- data.frame(upstreams, full_seqs, names)

to_write = c()

for(i in 1:nrow(final_df)){
  to_write <- c(to_write, paste0(">", final_df$names[i]), final_df$upstreams[i],
                paste0(">", final_df$names[i], "_with_cryptic"), final_df$full_seqs[i])
}

write_lines(to_write, "curated_riboseq_periodicity/cryptic_fasta.fasta")
